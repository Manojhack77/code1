import { useEffect } from "react";

export const inputCls =
  "w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 disabled:cursor-not-allowed disabled:bg-slate-50 disabled:text-slate-500";

export function Field({ label, hint, children }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-medium text-slate-700">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-xs text-slate-500">{hint}</span>}
    </label>
  );
}

const buttonStyles = {
  primary: "bg-blue-600 text-white hover:bg-blue-700 focus-visible:outline-blue-600",
  secondary: "border border-slate-300 bg-white text-slate-700 hover:bg-slate-50 focus-visible:outline-slate-400",
  danger: "bg-red-600 text-white hover:bg-red-700 focus-visible:outline-red-600",
  ghost: "text-blue-600 hover:bg-blue-50 focus-visible:outline-blue-600",
};

export function Button({ variant = "primary", small = false, className = "", ...props }) {
  return (
    <button
      {...props}
      className={`rounded-lg font-medium transition focus-visible:outline-2 focus-visible:outline-offset-2 disabled:cursor-not-allowed disabled:opacity-50 ${
        small ? "px-3 py-1.5 text-sm" : "px-5 py-2.5 text-sm"
      } ${buttonStyles[variant]} ${className}`}
    />
  );
}

export function Alert({ type = "error", children }) {
  if (!children) return null;
  const tone =
    type === "success"
      ? "border-emerald-200 bg-emerald-50 text-emerald-800"
      : "border-red-200 bg-red-50 text-red-800";
  return (
    <p role={type === "error" ? "alert" : "status"} className={`rounded-lg border px-4 py-2.5 text-sm ${tone}`}>
      {children}
    </p>
  );
}

export function Badge({ tone = "slate", children }) {
  const tones = {
    slate: "bg-slate-100 text-slate-700",
    green: "bg-emerald-100 text-emerald-800",
    red: "bg-red-100 text-red-800",
    amber: "bg-amber-100 text-amber-800",
  };
  return <span className={`inline-block rounded-full px-2.5 py-0.5 text-xs font-medium ${tones[tone]}`}>{children}</span>;
}

export function Modal({ title, onClose, children }) {
  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4"
      onMouseDown={(e) => e.target === e.currentTarget && onClose()}
    >
      <div role="dialog" aria-modal="true" aria-label={title} className="w-full max-w-md rounded-xl bg-white p-6 shadow-xl">
        <h3 className="mb-4 text-lg font-semibold text-slate-800">{title}</h3>
        {children}
      </div>
    </div>
  );
}

export function Card({ className = "", children }) {
  return <div className={`rounded-xl border border-slate-200 bg-white shadow-sm ${className}`}>{children}</div>;
}

export function Th({ right, children }) {
  return (
    <th className={`px-5 py-3.5 font-medium text-slate-600 ${right ? "text-right" : ""}`}>{children}</th>
  );
}

export function Td({ right, strong, children, className = "" }) {
  return (
    <td className={`px-5 py-3.5 ${strong ? "font-medium text-slate-800" : "text-slate-700"} ${right ? "text-right" : ""} ${className}`}>
      {children}
    </td>
  );
}

export function EmptyRow({ cols, children }) {
  return (
    <tr>
      <td colSpan={cols} className="px-5 py-10 text-center text-sm text-slate-500">
        {children}
      </td>
    </tr>
  );
}
