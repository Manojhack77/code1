import { Navigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import AppShell from "./AppShell";

export const homeFor = (user) => (user?.role === "ADMIN" ? "/admin" : "/staff");

// RBAC on the client: wrong role is sent to its own home. The backend must enforce the same.
export default function ProtectedRoute({ role, children }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (role && user.role !== role) return <Navigate to={homeFor(user)} replace />;
  return <AppShell>{children}</AppShell>;
}
