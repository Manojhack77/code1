// Flip VITE_USE_MOCK=false in .env once the Spring Boot backend is running.
export const USE_MOCK = import.meta.env.VITE_USE_MOCK !== "false";
export const API_URL = import.meta.env.VITE_API_URL || "http://localhost:8080";

// Hourly rates are no longer a constant: each staff member belongs to one of 5 rate
// categories, and admins edit the category names and rates on the Rates tab.
