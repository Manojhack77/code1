import axios from "axios";
import { API_URL, USE_MOCK } from "../config";
import { api as mock } from "./mockServer";

export const AUTH_KEY = "mhb_auth";

const http = axios.create({ baseURL: API_URL });

http.interceptors.request.use((cfg) => {
  try {
    const token = JSON.parse(localStorage.getItem(AUTH_KEY) || "null")?.token;
    if (token) cfg.headers.Authorization = `Bearer ${token}`;
  } catch {
    /* ignore corrupt storage */
  }
  return cfg;
});

http.interceptors.response.use(
  (r) => r,
  (e) => {
    // Expired / invalid token on a protected call -> back to login.
    if (e.response?.status === 401 && !e.config?.url?.includes("/api/auth/")) {
      localStorage.removeItem(AUTH_KEY);
      window.location.assign("/login");
    }
    return Promise.reject(e);
  },
);

const data = (p) => p.then((r) => r.data);

// Endpoint paths follow the spec; see API_CONTRACT.md for the full list.
const real = {
  login: (b) => data(http.post("/api/auth/login", b)),
  signup: (b) => data(http.post("/api/auth/signup", b)),
  forgotQuestion: (b) => data(http.post("/api/auth/forgot/question", b)),
  forgotReset: (b) => data(http.post("/api/auth/forgot/reset", b)),

  staffProjects: (memberId) => data(http.get(`/api/staff/projects/${memberId}`)),
  staffHistory: (memberId) => data(http.get(`/api/staff/history/${memberId}`)),
  bookHours: (b) => data(http.post("/api/staff/book", b)),
  updateHours: ({ id, hours }) =>
    data(http.patch(`/api/staff/update-hours/${id}`, null, { params: { hours } })),

  adminBookings: (params) => data(http.get("/api/admin/bookings", { params })),
  adminProjects: () => data(http.get("/api/admin/projects")),
  createProject: (b) => data(http.post("/api/admin/projects", b)),
  updateProject: (wbs, b) => data(http.put(`/api/admin/projects/${wbs}`, b)),
  deleteProject: (wbs) => data(http.delete(`/api/admin/projects/${wbs}`)),
  adminStaff: () => data(http.get("/api/admin/staff")),
  adminResetPassword: (memberId, password) =>
    data(http.put(`/api/admin/staff/${memberId}/password`, { password })),
  adminCategories: () => data(http.get("/api/admin/categories")),
  updateCategory: (id, b) => data(http.put(`/api/admin/categories/${id}`, b)),
  setStaffCategory: (memberId, categoryId) =>
    data(http.put(`/api/admin/staff/${memberId}/category`, { categoryId })),
  adminMappings: () => data(http.get("/api/admin/mappings")),
  createMapping: (b) => data(http.post("/api/admin/mappings", b)),
  deleteMapping: (id) => data(http.delete(`/api/admin/mappings/${id}`)),
};

export const api = USE_MOCK ? mock : real;
export const isMock = USE_MOCK;
export const resetDemo = USE_MOCK ? mock.resetDemo : null;
