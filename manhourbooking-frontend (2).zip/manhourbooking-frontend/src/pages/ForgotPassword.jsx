import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { api } from "../api";
import { Alert, Button, Card, Field, inputCls } from "../components/ui";
import { errMsg } from "../utils";

// Offline recovery: look up the clue question, answer it, then choose a new password.
export default function ForgotPassword() {
  const navigate = useNavigate();
  const [userId, setUserId] = useState("");
  const [question, setQuestion] = useState(null);
  const [answer, setAnswer] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [done, setDone] = useState("");
  const [busy, setBusy] = useState(false);

  const findAccount = async (e) => {
    e.preventDefault();
    if (!userId.trim()) return setError("Enter your user ID.");
    setBusy(true);
    setError("");
    try {
      const res = await api.forgotQuestion({ userId: userId.trim() });
      setQuestion(res.question);
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  const reset = async (e) => {
    e.preventDefault();
    if (!answer.trim()) return setError("Enter the answer to your clue question.");
    if (password.length < 6) return setError("Password must be at least 6 characters.");
    if (password !== confirm) return setError("Passwords do not match.");
    setBusy(true);
    setError("");
    try {
      const res = await api.forgotReset({ userId: userId.trim(), answer, newPassword: password });
      setDone(res.message);
      setTimeout(() => navigate("/login", { replace: true }), 1800);
    } catch (err) {
      setError(errMsg(err));
      setBusy(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-50 p-4">
      <div className="w-full max-w-sm">
        <h1 className="mb-1 text-2xl font-semibold text-slate-800">Reset your password</h1>
        <p className="mb-6 text-sm text-slate-500">
          {question ? "Answer the clue question you chose at sign-up." : "Enter your user ID to find your clue question."}
        </p>

        <Card className="p-6">
          {!question ? (
            <form onSubmit={findAccount} noValidate className="space-y-4">
              <Field label="User ID">
                <input className={inputCls} value={userId} onChange={(e) => setUserId(e.target.value)} autoFocus />
              </Field>
              <Alert>{error}</Alert>
              <Button type="submit" className="w-full" disabled={busy}>{busy ? "Looking up..." : "Continue"}</Button>
            </form>
          ) : (
            <form onSubmit={reset} noValidate className="space-y-4">
              <div className="rounded-lg bg-slate-50 px-4 py-3 text-sm text-slate-700">{question}</div>
              <Field label="Your answer">
                <input className={inputCls} value={answer} onChange={(e) => setAnswer(e.target.value)} autoFocus autoComplete="off" />
              </Field>
              <Field label="New password" hint="At least 6 characters.">
                <input type="password" className={inputCls} value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="new-password" />
              </Field>
              <Field label="Confirm new password">
                <input type="password" className={inputCls} value={confirm} onChange={(e) => setConfirm(e.target.value)} autoComplete="new-password" />
              </Field>
              <Alert>{error}</Alert>
              <Alert type="success">{done}</Alert>
              <Button type="submit" className="w-full" disabled={busy || !!done}>{busy ? "Saving..." : "Change password"}</Button>
            </form>
          )}
        </Card>

        <p className="mt-4 text-center text-sm text-slate-600">
          Forgot your answer too? Ask your administrator to reset it.
        </p>
        <p className="mt-2 text-center text-sm">
          <Link to="/login" className="font-medium text-blue-600 hover:text-blue-800">Back to log in</Link>
        </p>
      </div>
    </div>
  );
}
