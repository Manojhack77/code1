import { useState } from "react";
import DashboardTab from "./admin/DashboardTab";
import ProjectsTab from "./admin/ProjectsTab";
import MappingTab from "./admin/MappingTab";
import RatesTab from "./admin/RatesTab";

const TABS = [
  { id: "dashboard", label: "Dashboard" },
  { id: "projects", label: "Projects" },
  { id: "mapping", label: "Member mapping" },
  { id: "rates", label: "Staff and rates" },
];

export default function Admin() {
  const [tab, setTab] = useState("dashboard");

  return (
    <div>
      <div role="tablist" className="mb-6 flex gap-1 border-b border-slate-200">
        {TABS.map((t) => (
          <button
            key={t.id}
            role="tab"
            aria-selected={tab === t.id}
            onClick={() => setTab(t.id)}
            className={`-mb-px border-b-2 px-4 py-2.5 text-sm font-medium transition focus-visible:outline-2 focus-visible:outline-blue-600 ${
              tab === t.id ? "border-blue-600 text-blue-700" : "border-transparent text-slate-500 hover:text-slate-800"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>
      {tab === "dashboard" && <DashboardTab />}
      {tab === "projects" && <ProjectsTab />}
      {tab === "mapping" && <MappingTab />}
      {tab === "rates" && <RatesTab />}
    </div>
  );
}
