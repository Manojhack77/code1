import { useCallback, useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";
import { api } from "../api";
import { Alert, Badge, Button, Card, EmptyRow, Field, Modal, Td, Th, inputCls } from "../components/ui";
import { errMsg, monthName } from "../utils";

export default function Staff() {
  const { user } = useAuth();
  const now = new Date();
  const month = now.getMonth() + 1;
  const year = now.getFullYear();

  const [projects, setProjects] = useState([]);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [hours, setHours] = useState("");
  const [feedback, setFeedback] = useState(null); // { type, text }
  const [busy, setBusy] = useState(false);
  const [viewing, setViewing] = useState(null); // history row shown in the edit modal

  const load = useCallback(async () => {
    try {
      const [p, h] = await Promise.all([api.staffProjects(user.memberId), api.staffHistory(user.memberId)]);
      setProjects(p);
      setHistory(h);
    } catch (e) {
      setFeedback({ type: "error", text: errMsg(e) });
    } finally {
      setLoading(false);
    }
  }, [user.memberId]);

  useEffect(() => {
    load();
  }, [load]);

  const alreadyBooked = history.some((h) => h.month === month && h.year === year);
  const total = Number(hours);
  const activeProjects = projects.filter((p) => p.status !== "Expired");

  const submit = async (e) => {
    e.preventDefault();
    if (hours === "") return setFeedback({ type: "error", text: "Enter your working hours." });
    if (!(total > 0)) return setFeedback({ type: "error", text: "Working hours must be greater than zero." });
    setBusy(true);
    setFeedback(null);
    try {
      await api.bookHours({ memberId: user.memberId, month, year, hours: total });
      setFeedback({ type: "success", text: "Hours submitted successfully!" });
      setHours("");
      await load();
    } catch (err) {
      setFeedback({ type: "error", text: errMsg(err) });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Step 2: booking interface */}
      <section>
        <h2 className="text-2xl font-semibold text-slate-800">Monthly hours</h2>
        <p className="mb-5 mt-1 text-sm text-slate-500">Enter the hours you worked this month. They are split across your projects by allocation.</p>

        <div className="grid gap-6 lg:grid-cols-5">
          <Card className="p-6 lg:col-span-3">
            <form onSubmit={submit} noValidate className="space-y-5">
              <div className="grid gap-5 sm:grid-cols-2">
                <Field label="Month">
                  <input className={inputCls} value={monthName(month)} readOnly disabled />
                </Field>
                <Field label="Year">
                  <input className={inputCls} value={year} readOnly disabled />
                </Field>
              </div>

              <Field label="Working hours">
                <input
                  type="number" min="0" step="0.5" inputMode="decimal"
                  className={inputCls} value={hours} placeholder="Enter working hours, e.g. 160"
                  disabled={alreadyBooked}
                  onChange={(e) => {
                    setHours(e.target.value);
                    setFeedback(null);
                  }}
                />
              </Field>

              {alreadyBooked && (
                <Alert type="success">
                  You have already submitted hours for {monthName(month)} {year}. Use View in the history below to change them.
                </Alert>
              )}
              {feedback && <Alert type={feedback.type}>{feedback.text}</Alert>}

              <Button type="submit" disabled={busy || alreadyBooked || (!loading && projects.length === 0)}>
                {busy ? "Submitting..." : "Submit hours"}
              </Button>
            </form>
          </Card>

          {/* FR-1.1: only projects the staff member is mapped to */}
          <Card className="p-6 lg:col-span-2">
            <h3 className="font-semibold text-slate-800">Your projects</h3>
            {loading ? (
              <p className="mt-3 text-sm text-slate-500">Loading...</p>
            ) : projects.length === 0 ? (
              <p className="mt-3 text-sm text-slate-500">
                You are not assigned to any project yet. Ask your administrator to add you.
              </p>
            ) : (
              <ul className="mt-3 divide-y divide-slate-100">
                {projects.map((p) => {
                  const share = total > 0 ? (total * p.allocationPercentage) / 100 : null;
                  return (
                    <li key={p.wbsCode} className="py-3 text-sm">
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-medium text-slate-800">{p.projectName}</span>
                        {p.status === "Expired" ? <Badge tone="red">Expired</Badge> : <Badge tone="slate">{p.allocationPercentage}%</Badge>}
                      </div>
                      <p className="text-slate-500">{p.wbsCode}</p>
                      {share !== null && p.status !== "Expired" && (
                        <p className="mt-1 text-slate-700">
                          {Number(share.toFixed(2))} h of your total
                        </p>
                      )}
                    </li>
                  );
                })}
              </ul>
            )}
            {projects.length > 0 && activeProjects.length < projects.length && (
              <p className="mt-3 text-xs text-red-700">Expired projects are locked. Bookings to them will be rejected.</p>
            )}
          </Card>
        </div>
      </section>

      {/* Step 3: booking history */}
      <section>
        <h2 className="text-xl font-semibold text-slate-800">Booking history</h2>
        <p className="mb-4 mt-1 text-sm text-slate-500">Your previously submitted months.</p>
        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="border-b border-slate-200 bg-slate-50">
                <tr>
                  <Th>Month / year</Th>
                  <Th>Hours</Th>
                  <Th right>Action</Th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {loading ? (
                  <EmptyRow cols={3}>Loading...</EmptyRow>
                ) : history.length === 0 ? (
                  <EmptyRow cols={3}>No hours submitted yet. Your first entry will appear here.</EmptyRow>
                ) : (
                  history.map((h) => (
                    <tr key={h.id} className="hover:bg-slate-50">
                      <Td>{monthName(h.month)} {h.year}</Td>
                      <Td strong>{h.hours}</Td>
                      <Td right>
                        <Button variant="ghost" small onClick={() => setViewing(h)}>View</Button>
                      </Td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </Card>
      </section>

      {viewing && (
        <EditModal
          row={viewing}
          onClose={() => setViewing(null)}
          onSaved={async () => {
            setViewing(null);
            setFeedback({ type: "success", text: "Hours updated." });
            await load();
          }}
        />
      )}
    </div>
  );
}

// Step 4: modification. Month and year are read-only, hours are editable.
function EditModal({ row, onClose, onSaved }) {
  const [hours, setHours] = useState(String(row.hours));
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const update = async () => {
    const n = Number(hours);
    if (hours === "" || !(n >= 0)) return setError("Enter a valid number of hours.");
    setBusy(true);
    setError("");
    try {
      await api.updateHours({ id: row.id, hours: n });
      await onSaved();
    } catch (e) {
      setError(errMsg(e));
      setBusy(false);
    }
  };

  return (
    <Modal title="Edit hours" onClose={onClose}>
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <Field label="Month">
            <input className={inputCls} value={monthName(row.month)} disabled readOnly />
          </Field>
          <Field label="Year">
            <input className={inputCls} value={row.year} disabled readOnly />
          </Field>
        </div>
        <Field label="Hours">
          <input type="number" min="0" step="0.5" className={inputCls} value={hours} autoFocus onChange={(e) => setHours(e.target.value)} />
        </Field>
        <Alert>{error}</Alert>
        <div className="flex justify-end gap-3">
          <Button variant="secondary" onClick={onClose}>Cancel</Button>
          <Button onClick={update} disabled={busy}>{busy ? "Updating..." : "Update"}</Button>
        </div>
      </div>
    </Modal>
  );
}
