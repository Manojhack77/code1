import { useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { homeFor } from "../components/ProtectedRoute";
import { Alert, Button, Card, Field, inputCls } from "../components/ui";
import { isMock, resetDemo } from "../api";
import { errMsg } from "../utils";

export default function Login() {
  const { user, login } = useAuth();
  const navigate = useNavigate();
  const [userId, setUserId] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  if (user) return <Navigate to={homeFor(user)} replace />;

  const submit = async (e) => {
    e.preventDefault();
    if (!userId.trim() || !password) return setError("Enter your user ID and password.");
    setBusy(true);
    setError("");
    try {
      const u = await login(userId, password);
      navigate(homeFor(u), { replace: true }); // staff -> staff dashboard, admin -> admin dashboard
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-50 p-4">
      <div className="w-full max-w-sm">
        <h1 className="mb-1 text-2xl font-semibold text-slate-800">ManHourBooking</h1>
        <p className="mb-6 text-sm text-slate-500">Log in to book your hours or manage projects.</p>

        <Card className="p-6">
          <form onSubmit={submit} className="space-y-4" noValidate>
            <Field label="User ID">
              <input className={inputCls} value={userId} onChange={(e) => setUserId(e.target.value)} autoComplete="username" autoFocus />
            </Field>
            <Field label="Password">
              <input type="password" className={inputCls} value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" />
            </Field>
            <Alert>{error}</Alert>
            <Button type="submit" className="w-full" disabled={busy}>
              {busy ? "Logging in..." : "Log in"}
            </Button>
          </form>
        </Card>

        <p className="mt-4 text-center text-sm">
          <Link to="/forgot-password" className="font-medium text-blue-600 hover:text-blue-800">
            Forgot password?
          </Link>
        </p>
        <p className="mt-2 text-center text-sm text-slate-600">
          New staff member?{" "}
          <Link to="/signup" className="font-medium text-blue-600 hover:text-blue-800">
            Create an account
          </Link>
        </p>

        {isMock && (
          <div className="mt-6 rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
            <p className="font-medium">Demo accounts</p>
            <p className="mt-1">Admin: ADMIN01 / admin123</p>
            <p>Staff: ST1025 / staff123</p>
            <p>Clue answer for demo accounts: greenfield</p>
            <button
              type="button"
              className="mt-2 text-xs underline"
              onClick={async () => {
                await resetDemo();
                setError("");
                setUserId("");
                setPassword("");
              }}
            >
              Reset demo data
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
