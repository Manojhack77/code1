import { useCallback, useEffect, useState } from "react";
import { api } from "../../api";
import { Alert, Badge, Button, Card, EmptyRow, Field, Td, Th, inputCls } from "../../components/ui";
import { errMsg, isExpired } from "../../utils";

// FR-2.4: map staff to projects with an allocation %, total per staff <= 100.
export default function MappingTab() {
  const [staff, setStaff] = useState([]);
  const [projects, setProjects] = useState([]);
  const [mappings, setMappings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ memberId: "", wbsCode: "", allocationPercentage: "" });
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const [s, p, m] = await Promise.all([api.adminStaff(), api.adminProjects(), api.adminMappings()]);
      setStaff(s);
      setProjects(p);
      setMappings(m);
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const set = (k) => (e) => {
    setForm((f) => ({ ...f, [k]: e.target.value }));
    setError("");
    setNotice("");
  };

  const selected = staff.find((s) => s.memberId === form.memberId);
  const remaining = selected ? 100 - selected.totalAllocation : null;
  const openProjects = projects.filter((p) => !isExpired(p.expiryDate));

  const submit = async (e) => {
    e.preventDefault();
    const pct = Number(form.allocationPercentage);
    if (!form.memberId || !form.wbsCode) return setError("Choose a staff member and a project.");
    if (!(pct > 0 && pct <= 100)) return setError("Allocation must be between 1 and 100.");
    if (remaining !== null && pct > remaining)
      return setError(`${selected.name} has only ${remaining}% left to allocate.`);
    setBusy(true);
    try {
      await api.createMapping({ memberId: form.memberId, wbsCode: form.wbsCode, allocationPercentage: pct });
      setNotice(`${selected.name} assigned ${pct}% to ${form.wbsCode}.`);
      setForm((f) => ({ ...f, wbsCode: "", allocationPercentage: "" }));
      await load();
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  const remove = async (m) => {
    try {
      await api.deleteMapping(m.mappingId);
      setNotice(`${m.staffName} removed from ${m.wbsCode}.`);
      setError("");
      await load();
    } catch (e) {
      setError(errMsg(e));
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold text-slate-800">Member mapping</h2>
        <p className="mt-1 text-sm text-slate-500">Assign staff to projects. Each staff member can be allocated up to 100% in total.</p>
      </div>

      <Card className="p-6">
        <form onSubmit={submit} noValidate className="grid items-start gap-4 md:grid-cols-4">
          <Field label="Staff member" hint={selected ? `${remaining}% left to allocate` : undefined}>
            <select className={inputCls} value={form.memberId} onChange={set("memberId")}>
              <option value="">Select staff</option>
              {staff.map((s) => (
                <option key={s.memberId} value={s.memberId}>{s.name} ({s.memberId})</option>
              ))}
            </select>
          </Field>
          <Field label="Project (WBS)">
            <select className={inputCls} value={form.wbsCode} onChange={set("wbsCode")}>
              <option value="">Select project</option>
              {openProjects.map((p) => (
                <option key={p.wbsCode} value={p.wbsCode}>{p.wbsCode} - {p.projectName}</option>
              ))}
            </select>
          </Field>
          <Field label="Allocation %">
            <input type="number" min="1" max="100" className={inputCls} placeholder="e.g. 50" value={form.allocationPercentage} onChange={set("allocationPercentage")} />
          </Field>
          <div className="md:pt-7">
            <Button type="submit" className="w-full" disabled={busy}>{busy ? "Saving..." : "Assign"}</Button>
          </div>
        </form>
        <div className="mt-4 space-y-2">
          <Alert>{error}</Alert>
          <Alert type="success">{notice}</Alert>
        </div>
      </Card>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-slate-200 bg-slate-50">
              <tr>
                <Th>Staff</Th>
                <Th>WBS code</Th>
                <Th>Project name</Th>
                <Th>Allocation</Th>
                <Th>Staff total</Th>
                <Th right>Action</Th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <EmptyRow cols={6}>Loading...</EmptyRow>
              ) : mappings.length === 0 ? (
                <EmptyRow cols={6}>No assignments yet. Use the form above to add the first one.</EmptyRow>
              ) : (
                mappings.map((m) => {
                  const total = staff.find((s) => s.memberId === m.memberId)?.totalAllocation ?? 0;
                  return (
                    <tr key={m.mappingId} className="hover:bg-slate-50">
                      <Td strong>{m.staffName} <span className="font-normal text-slate-500">({m.memberId})</span></Td>
                      <Td>{m.wbsCode}</Td>
                      <Td>
                        {m.projectName} {m.projectExpired && <Badge tone="red">Expired</Badge>}
                      </Td>
                      <Td strong>{m.allocationPercentage}%</Td>
                      <Td>
                        <Badge tone={total === 100 ? "green" : "amber"}>{total}%</Badge>
                      </Td>
                      <Td right>
                        <Button small variant="ghost" className="!text-red-600 hover:!bg-red-50" onClick={() => remove(m)}>Remove</Button>
                      </Td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
