import { useEffect, useState } from "react";
import { api } from "../../api";
import { Alert, Button, Card, EmptyRow, Td, Th, inputCls } from "../../components/ui";
import { MONTHS, errMsg, fmtMoney, monthName } from "../../utils";

const thisYear = new Date().getFullYear();
const YEARS = Array.from({ length: 6 }, (_, i) => thisYear + 1 - i);

// FR-2.1 / FR-2.2: month-wise dashboard with filters (no page reload) and inline hour overrides.
export default function DashboardTab() {
  const [month, setMonth] = useState("");
  const [year, setYear] = useState("");
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [editId, setEditId] = useState(null);
  const [draft, setDraft] = useState("");
  const [saving, setSaving] = useState(false);
  const [reload, setReload] = useState(0);

  useEffect(() => {
    let stale = false;
    setLoading(true);
    api
      .adminBookings({ month: month || undefined, year: year || undefined })
      .then((r) => !stale && (setRows(r), setError("")))
      .catch((e) => !stale && setError(errMsg(e)))
      .finally(() => !stale && setLoading(false));
    return () => {
      stale = true;
    };
  }, [month, year, reload]);

  const startEdit = (r) => {
    setEditId(r.bookingId);
    setDraft(String(r.hoursBooked));
    setError("");
    setNotice("");
  };

  const save = async (r) => {
    const n = Number(draft);
    if (draft === "" || !(n >= 0)) return setError("Enter a valid number of hours.");
    setSaving(true);
    setError("");
    try {
      await api.updateHours({ id: r.bookingId, hours: n });
      setEditId(null);
      setNotice(`Saved. Budget for ${r.wbsCode} was recalculated.`);
      setReload((x) => x + 1);
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setSaving(false);
    }
  };

  const totalHours = rows.reduce((s, r) => s + r.hoursBooked, 0);
  const totalCost = rows.reduce((s, r) => s + r.calculatedCost, 0);

  return (
    <div>
      <div className="mb-5 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold text-slate-800">Bookings</h2>
          <p className="mt-1 text-sm text-slate-500">All staff bookings, split by project.</p>
        </div>
        <div className="flex items-end gap-3">
          <label className="block text-sm font-medium text-slate-700">
            <span className="mb-1.5 block">Select month</span>
            <select className={`${inputCls} w-40`} value={month} onChange={(e) => setMonth(e.target.value)}>
              <option value="">All months</option>
              {MONTHS.map((m, i) => (
                <option key={m} value={i + 1}>{m}</option>
              ))}
            </select>
          </label>
          <label className="block text-sm font-medium text-slate-700">
            <span className="mb-1.5 block">Select year</span>
            <select className={`${inputCls} w-32`} value={year} onChange={(e) => setYear(e.target.value)}>
              <option value="">All years</option>
              {YEARS.map((y) => (
                <option key={y} value={y}>{y}</option>
              ))}
            </select>
          </label>
        </div>
      </div>

      <div className="mb-4 space-y-2">
        <Alert>{error}</Alert>
        <Alert type="success">{notice}</Alert>
      </div>

      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-slate-200 bg-slate-50">
              <tr>
                <Th>WBS code</Th>
                <Th>Project name</Th>
                <Th>Staff name</Th>
                <Th>Hours booked</Th>
                <Th>Cost</Th>
                <Th>Month</Th>
                <Th>Year</Th>
                <Th right>Action</Th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <EmptyRow cols={8}>Loading...</EmptyRow>
              ) : rows.length === 0 ? (
                <EmptyRow cols={8}>No bookings for this selection. Try another month or year.</EmptyRow>
              ) : (
                rows.map((r) => (
                  <tr key={r.bookingId} className="hover:bg-slate-50">
                    <Td strong>{r.wbsCode}</Td>
                    <Td>{r.projectName}</Td>
                    <Td>{r.staffName}</Td>
                    <Td strong>
                      {editId === r.bookingId ? (
                        <input
                          type="number" min="0" step="0.5" autoFocus aria-label="Hours booked"
                          className={`${inputCls} w-28 py-1.5`} value={draft}
                          onChange={(e) => setDraft(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") save(r);
                            if (e.key === "Escape") setEditId(null);
                          }}
                        />
                      ) : (
                        r.hoursBooked
                      )}
                    </Td>
                    <Td>{fmtMoney(r.calculatedCost)}</Td>
                    <Td>{monthName(r.month)}</Td>
                    <Td>{r.year}</Td>
                    <Td right>
                      {editId === r.bookingId ? (
                        <span className="inline-flex gap-2">
                          <Button small onClick={() => save(r)} disabled={saving}>Save</Button>
                          <Button small variant="secondary" onClick={() => setEditId(null)}>Cancel</Button>
                        </span>
                      ) : r.projectExpired ? (
                        <span className="text-xs text-red-700">Project expired</span>
                      ) : (
                        <Button small variant="ghost" onClick={() => startEdit(r)}>Edit</Button>
                      )}
                    </Td>
                  </tr>
                ))
              )}
            </tbody>
            {!loading && rows.length > 0 && (
              <tfoot className="border-t border-slate-200 bg-slate-50 text-sm font-medium text-slate-800">
                <tr>
                  <td className="px-5 py-3" colSpan={3}>Total for this view</td>
                  <td className="px-5 py-3">{Number(totalHours.toFixed(2))}</td>
                  <td className="px-5 py-3">{fmtMoney(totalCost)}</td>
                  <td colSpan={3} />
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </Card>
    </div>
  );
}
