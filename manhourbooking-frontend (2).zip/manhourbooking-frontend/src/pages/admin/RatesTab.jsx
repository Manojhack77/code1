import { useCallback, useEffect, useState } from "react";
import { api } from "../../api";
import { Alert, Badge, Button, Card, EmptyRow, Field, Modal, Td, Th, inputCls } from "../../components/ui";
import { errMsg, fmtMoney } from "../../utils";

// Hourly rate categories (5) and which category each staff member belongs to.
// A booking is priced with the staff member's category rate at the time it is made.
export default function RatesTab() {
  const [categories, setCategories] = useState([]);
  const [staff, setStaff] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [editId, setEditId] = useState(null);
  const [draft, setDraft] = useState({ name: "", rate: "" });
  const [busy, setBusy] = useState(false);
  const [resetFor, setResetFor] = useState(null);
  const [newPass, setNewPass] = useState("");

  const load = useCallback(async () => {
    try {
      const [c, s] = await Promise.all([api.adminCategories(), api.adminStaff()]);
      setCategories(c);
      setStaff(s);
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const startEdit = (c) => {
    setEditId(c.categoryId);
    setDraft({ name: c.name, rate: String(c.rate) });
    setError("");
    setNotice("");
  };

  const saveCategory = async () => {
    if (!draft.name.trim()) return setError("Category name is required.");
    if (!(Number(draft.rate) > 0)) return setError("Rate must be greater than zero.");
    setBusy(true);
    setError("");
    try {
      await api.updateCategory(editId, { name: draft.name.trim(), rate: Number(draft.rate) });
      setEditId(null);
      setNotice("Rate saved. It applies to new bookings; past bookings keep the rate they were priced at.");
      await load();
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setBusy(false);
    }
  };

  const assign = async (s, categoryId) => {
    setError("");
    setNotice("");
    try {
      await api.setStaffCategory(s.memberId, Number(categoryId));
      setNotice(`${s.name} moved to ${categories.find((c) => c.categoryId === Number(categoryId))?.name}.`);
      await load();
    } catch (e) {
      setError(errMsg(e));
    }
  };

  const resetPassword = async () => {
    if (newPass.length < 6) return setError("Password must be at least 6 characters.");
    try {
      await api.adminResetPassword(resetFor.memberId, newPass);
      setNotice(`Password for ${resetFor.name} was reset. Share the new password with them in person.`);
      setError("");
      setResetFor(null);
      setNewPass("");
    } catch (e) {
      setError(errMsg(e));
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-xl font-semibold text-slate-800">Staff and rates</h2>
        <p className="mt-1 text-sm text-slate-500">Hourly cost for each category, the category of each staff member, and password resets. Staff cannot see rates.</p>
      </div>

      <div className="space-y-2">
        <Alert>{error}</Alert>
        <Alert type="success">{notice}</Alert>
      </div>

      <section>
        <h3 className="mb-3 font-semibold text-slate-800">Rate categories</h3>
        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="border-b border-slate-200 bg-slate-50">
                <tr>
                  <Th>Category</Th>
                  <Th>Rate per hour</Th>
                  <Th right>Action</Th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {loading ? (
                  <EmptyRow cols={3}>Loading...</EmptyRow>
                ) : (
                  categories.map((c) => (
                    <tr key={c.categoryId} className="hover:bg-slate-50">
                      <Td strong>
                        {editId === c.categoryId ? (
                          <input aria-label="Category name" className={`${inputCls} w-52 py-1.5`} value={draft.name} autoFocus
                            onChange={(e) => setDraft((d) => ({ ...d, name: e.target.value }))} />
                        ) : (
                          c.name
                        )}
                      </Td>
                      <Td>
                        {editId === c.categoryId ? (
                          <input type="number" min="0" step="0.01" aria-label="Rate per hour" className={`${inputCls} w-36 py-1.5`} value={draft.rate}
                            onChange={(e) => setDraft((d) => ({ ...d, rate: e.target.value }))}
                            onKeyDown={(e) => e.key === "Enter" && saveCategory()} />
                        ) : (
                          fmtMoney(c.rate)
                        )}
                      </Td>
                      <Td right>
                        {editId === c.categoryId ? (
                          <span className="inline-flex gap-2">
                            <Button small onClick={saveCategory} disabled={busy}>Save</Button>
                            <Button small variant="secondary" onClick={() => setEditId(null)}>Cancel</Button>
                          </span>
                        ) : (
                          <Button small variant="ghost" onClick={() => startEdit(c)}>Edit</Button>
                        )}
                      </Td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </Card>
      </section>

      <section>
        <h3 className="mb-3 font-semibold text-slate-800">Staff category</h3>
        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="border-b border-slate-200 bg-slate-50">
                <tr>
                  <Th>Staff</Th>
                  <Th>Category</Th>
                  <Th>Rate per hour</Th>
                  <Th right>Action</Th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {loading ? (
                  <EmptyRow cols={4}>Loading...</EmptyRow>
                ) : staff.length === 0 ? (
                  <EmptyRow cols={4}>No staff yet. Staff appear here after they sign up.</EmptyRow>
                ) : (
                  staff.map((s) => (
                    <tr key={s.memberId} className="hover:bg-slate-50">
                      <Td strong>{s.name} <span className="font-normal text-slate-500">({s.memberId})</span></Td>
                      <Td>
                        <select aria-label={`Category for ${s.name}`} className={`${inputCls} w-52 py-1.5`} value={s.categoryId ?? ""}
                          onChange={(e) => assign(s, e.target.value)}>
                          <option value="" disabled>Not set</option>
                          {categories.map((c) => (
                            <option key={c.categoryId} value={c.categoryId}>{c.name}</option>
                          ))}
                        </select>
                      </Td>
                      <Td>{s.rate ? fmtMoney(s.rate) : <Badge tone="amber">Set a category</Badge>}</Td>
                      <Td right>
                        <Button small variant="ghost" onClick={() => { setResetFor(s); setNewPass(""); setError(""); }}>Reset password</Button>
                      </Td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </Card>
        <p className="mt-2 text-xs text-slate-500">Staff without a category cannot submit hours.</p>
      </section>

      {resetFor && (
        <Modal title={`Reset password for ${resetFor.name}`} onClose={() => setResetFor(null)}>
          <div className="space-y-4">
            <Field label="New password" hint="At least 6 characters. Tell the staff member in person.">
              <input className={inputCls} value={newPass} autoFocus onChange={(e) => setNewPass(e.target.value)} />
            </Field>
            <div className="flex justify-end gap-3">
              <Button variant="secondary" onClick={() => setResetFor(null)}>Cancel</Button>
              <Button onClick={resetPassword}>Reset password</Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
