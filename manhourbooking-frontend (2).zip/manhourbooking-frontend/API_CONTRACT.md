# API contract (for the Spring Boot backend)

The frontend calls these endpoints when `VITE_USE_MOCK=false`. JWT goes in `Authorization: Bearer <token>`.
Errors: HTTP 4xx with JSON `{ "message": "..." }` (the UI shows `message` as-is). 401 sends the user to /login.
Money uses BigDecimal; months are integers 1-12.

## Auth (public)
- POST /api/auth/login   `{ userId, password }` -> `{ token, user: { memberId, name, role } }`  (role: STAFF | ADMIN)
- POST /api/auth/signup  `{ memberId, name, password, securityQuestion, securityAnswer }` -> same shape. Always creates STAFF.
  Store the password with BCrypt and the clue answer hashed too (trim + lowercase before hashing).
- POST /api/auth/forgot/question `{ userId }` -> `{ question }` (404 if no such user). Offline system: no email.
- POST /api/auth/forgot/reset `{ userId, answer, newPassword }` -> `{ message }`.
  Wrong answer -> 400 "That answer does not match."; lock after 5 wrong answers -> 400 "Too many wrong answers. Ask your administrator to reset your password."

## Staff (role STAFF)
- GET   /api/staff/projects/{memberId} -> `[{ wbsCode, projectName, expiryDate, status, allocationPercentage }]` (no budget, cost or rate fields) (only mapped projects, FR-1.1)
- GET   /api/staff/history/{memberId}  -> `[{ id, month, year, hours }]` one row per month (sum over WBS rows), newest first
- POST  /api/staff/book `{ memberId, month, year, hours }`
  Creates one Booking row per mapped WBS: hours_wbs = hours x allocation%, calculated_cost = hours_wbs x rate of the staff member's category, and the rate is saved on the row as rate_applied.
  Rejects when the staff member has no category. Staff-facing error messages must NOT include rates, costs or budget amounts (use e.g. "Your account is not ready for booking yet" and "Not enough budget left in WBS-1001. Ask your administrator.").
  Rejects: month already booked, project expired, cost > amount_available. Single @Transactional.
- PATCH /api/staff/update-hours/{id}?hours=  
  Staff: `id` is the `id` from history (mock uses `<memberId>_<year>_<month>`; the backend may choose any opaque id) and the new total is re-split across that month's WBS rows.
  Admin: `id` is a booking_id and only that row changes. Both recalculate Amount Booked / Available.

## Admin (role ADMIN)
- GET    /api/admin/bookings?month=&year=  -> `[{ bookingId, wbsCode, projectName, memberId, staffName, hoursBooked, calculatedCost, month, year, projectExpired }]`
- GET    /api/admin/projects -> `[{ wbsCode, projectName, expiryDate, amountAllotted, amountAvailable, amountBooked, status }]` (status = Expired when expiryDate < today)
- POST   /api/admin/projects `{ wbsCode, projectName, expiryDate, amountAllotted }`
- PUT    /api/admin/projects/{wbsCode} `{ projectName, expiryDate, amountAllotted }`  (available = allotted - booked; reject allotted < booked)
- DELETE /api/admin/projects/{wbsCode}  (reject if bookings exist)
- GET    /api/admin/staff -> `[{ memberId, name, totalAllocation, categoryId, categoryName, rate }]`
- PUT    /api/admin/staff/{memberId}/category `{ categoryId }`
- PUT    /api/admin/staff/{memberId}/password `{ password }`  (admin resets a staff password when the clue is forgotten; also clears the lock)
- GET    /api/admin/categories -> `[{ categoryId, name, rate }]` (exactly 5 rows)
- PUT    /api/admin/categories/{categoryId} `{ name, rate }`  (affects new bookings only)
- GET    /api/admin/mappings -> `[{ mappingId, wbsCode, projectName, memberId, staffName, allocationPercentage, projectExpired }]`
- POST   /api/admin/mappings `{ memberId, wbsCode, allocationPercentage }`  (reject if staff total > 100, duplicate pair, or expired project)
- DELETE /api/admin/mappings/{mappingId}

## Rules the backend must enforce (spec FR-3.x, section 5)
Amount Booked += cost; Amount Available -= cost; Available = Allotted - Booked always; expired projects lock all booking and budget changes; RBAC on every route.
Rates: 5 categories, each with a rate; each staff member has one category. Edits of an existing booking use that row's rate_applied, so changing a category rate never rewrites history.
Rates, costs and budgets are admin-only: no STAFF endpoint may return them.
Signup creates staff with no category; an admin must set it before the staff member can book.
